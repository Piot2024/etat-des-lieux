V23 OFFLINE iPad

Ne pas ouvrir index.html directement dans Fichiers sur iPad.

Installation correcte:
1. Publier ce dossier une fois sur un lien HTTPS.
2. Ouvrir ce lien dans Safari sur iPad.
3. Partager > Ajouter à l’écran d’accueil.
4. Ouvrir l’application depuis l’icône.
5. Après la première ouverture complète, l’application fonctionne hors ligne.

Les données, photos, pièces, signatures et PDF restent locaux sur l’appareil.
